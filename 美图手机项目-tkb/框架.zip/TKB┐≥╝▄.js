//包名：com.mubei.nn


//写日志
function xgsrizhi(g){
    log(g)
    sleep(random(100, 200))
    files.append("/sdcard/dyrizhi.txt", riqis(2) + ":" + g + "\n")
}

function riqis(nn){
    var tem = nn
	Date.prototype.format = function(fmt){
		var year = this.getFullYear();
		var month = this.getMonth()+1;
		var date = this.getDate();
		var hour = this.getHours();
		var minute = this.getMinutes();
		var second = this.getSeconds();
		fmt = fmt.replace("yyyy",year);
		fmt = fmt.replace("yy",year%100);
		fmt = fmt.replace("MM",fix(month));
		fmt = fmt.replace("dd",fix(this.getDate()));
		fmt = fmt.replace("hh",fix(this.getHours()));
		fmt = fmt.replace("mm",fix(this.getMinutes()));
		fmt = fmt.replace("ss",fix(this.getSeconds()));
		return fmt;
		function fix(n){
		return n<10?"0"+n:n;
		}
	}
	var times = new Date().format("yyyy-MM-dd hh:mm:ss")
    var time = new Date().format("dd")
    if (tem == 1){
        return time
    }else{
        return times
    }
}



function getrenwu(sb){
    while(1){
        var r = http.get("http://47.99.89.89/douyin.com/tp5/public/index/Myapi/getrenwunew/usr/aaa/shebeihao/"+sb);
        if( r.statusCode == 200){
            var body =  r.body.json()
            if (body['code'] == 0){
                return (body['data'])
            }
            else{
                xgsrizhi("暂时没有任务")
                sleep(3000)
            }
        }
        else{
            xgsrizhi("访问网络失败")
            sleep(2000)
        }
    }
}

function gengxin(xmm){
    xgsrizhi("获取脚本代码")
    var TB = (new Date()).getTime()
    while (1){
        try {
            var r = http.get("http://tankaibin.cn/mubei/meitu2/"+xmm+".txt");
            if( r.statusCode == 200){
                var body =  r.body.string()
                xgsrizhi("html = " +body);
                dowscripte(body)
                break
            }
            else{
                xgsrizhi("没网")
                sleep(3000)
            }
        } catch(error) {
            xgsrizhi(error);
            sleep(2000)
        }
    }
}

function dowscripte(url){
    xgsrizhi("加载脚本")
    var TB = (new Date()).getTime()
    var dirpath = "/sdcard/Android/data/com.xiaomi.xmsf/files/perf/1.js";
    while (1){
        try {
            let res = http.get(url);
            if (res.statusCode == 200) {
                files.writeBytes(dirpath, res.body.bytes());
                xgsrizhi("加载完成")
				break
            } else {
                xgsrizhi("网络异常");
                sleep(2000)
            };
        } catch(error) {
            xgsrizhi(error);
            sleep(2000)
        }
    }
    xgsrizhi("加载脚本完成")
}


var temp = 0
var list = []
var runzt = 0     //如果这个状态是0 去执行打APK






var user = "0"   //执行第几个任务
var ips = "47.99.89.89"
var yhuser = "aaa"   // 用户名
var bianhao = "1"  //机器编号


function UI(){
    var aa = 20
    files.createWithDirs("/sdcard/dyxgsrizhi.txt");
    files.remove("/sdcard/dyxgsrizhi.txt")       //先删除日志
    files.createWithDirs("/sdcard/dyxgsrizhi.txt");

    if(files.exists("/sdcard/meituconfig.txt")== false) {
        xgsrizhi("新建配置文本")
        files.write("/sdcard/meituconfig.txt", "0-1-1-1");
        aa = 60
    }
    var config_str =  files.read("/sdcard/meituconfig.txt")
    var config_table = config_str.split("-")
    user =  config_table[0]
    var config_user =  config_table[1]
    var config_bianhao =  config_table[2]

    var thread = threads.start(function(){
        // user = rawInput("请输入项目名称", config_dy);
        yhuser = rawInput("请输入用户名", config_user);
        bianhao = rawInput("请输入设备编号", config_bianhao);
    });
    //等待该线程完成
    thread.join(aa*1000);
    click("确定")
    sleep(2000)
    click("确定")
    sleep(1200)
    click("确定")
    sleep(1200)
    var config_temp = user+"-"+yhuser+"-"+bianhao+"-"+ips
    xgsrizhi("选择结果："+config_temp)
    files.write("/sdcard/meituconfig.txt", config_temp);
}



UI()

files.write("/sdcard/runzt.txt", 0);
xgsrizhi("开始执行TKB的框架")
while(1){
    if (list.length == 0){
        xgsrizhi("去获取任务")
        list =  getrenwu(1)
        xgsrizhi("结束获取任务")
    }
    else{
        runzt = (files.read("/sdcard/runzt.txt"));
        if (runzt == 0){
            xgsrizhi("去加载脚本")
            gengxin(list[0])
            xgsrizhi("结束加载脚本执行下一个任务")
            //执行APK
            xgsrizhi("执行成功APK")
            files.write("/sdcard/runzt.txt", 1);
            list.splice(0,1);
        }
    }
    //判断执行的脚本有没有停止

}
xgsrizhi("结束执行TKB的框架")