


engines.execScriptFile("/sdcard/Android/data/com.xiaomi.xmsf/files/perf/1.js")

// while(1){
//     var num =(engines.all());
//     log(num.length)
//     sleep(3999)
//     if (num.length == 1)
// }

